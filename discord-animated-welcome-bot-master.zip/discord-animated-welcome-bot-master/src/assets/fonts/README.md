Find the following fonts and place .ttf files here (distribution details unknown at time of writing, openly shared at dafont.com):

- rounded_elegance/
  - Rounded_Elegance.ttf
- roboto/
  - Roboto-Medium.ttf
  - Roboto-MediumItalic.ttf
  - Roboto-Regular.ttf
